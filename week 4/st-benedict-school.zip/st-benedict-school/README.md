# St Benedict School

A Pen created on CodePen.io. Original URL: [https://codepen.io/erinayo30/pen/qBYMmVV](https://codepen.io/erinayo30/pen/qBYMmVV).

SS2 class Score sheet