# Zuri Cohort 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/erinayo30/pen/OJZQzdM](https://codepen.io/erinayo30/pen/OJZQzdM).

